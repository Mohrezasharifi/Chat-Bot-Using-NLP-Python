from flask import Flask, render_template, request
from transformers import AutoTokenizer, AutoModelForCausalLM
from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer


from chatterbot import ChatBot
from chatterbot.trainers import ListTrainer
import os

# Check if the saved_conversations directory is empty
if not os.listdir('saved_conversations'):
    filenumber = 1
else:
    # Get the last file name in the directory
    last_file_name = os.listdir('saved_conversations')[-1]

    # Extract the number from the file name if it contains a number
    if last_file_name.split('.')[0].isdigit():
        filenumber = int(last_file_name.split('.')[0])
    else:
        filenumber = 1

    # Increment the number to get the next file number
    filenumber += 1

# Create a new conversation file with the next file number
file = open(f'saved_conversations/{filenumber}.txt', 'w+')
file.write('bot : Hi There! I am a medical chatbot. You can begin conversation by typing in a message and pressing enter.\n')
file.close()

app = Flask(__name__)

# Load the pre-trained model
tokenizer = AutoTokenizer.from_pretrained("EleutherAI/gpt-neo-1.3B")
model = AutoModelForCausalLM.from_pretrained("EleutherAI/gpt-neo-1.3B")

# Create a function to generate responses using the ChatGPT model
def generate_response(user_input):
    # Tokenize user input
    input_ids = tokenizer.encode(user_input, return_tensors='pt')
    
    # Generate responses
    output = model.generate(input_ids, max_length=50, do_sample=True)
    
    # Decode response
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    
    return response

english_bot = ChatBot('Bot',
             storage_adapter='chatterbot.storage.SQLStorageAdapter',
             logic_adapters=[
   {
       'import_path': 'chatterbot.logic.BestMatch'
   },
   
],
trainer='chatterbot.trainers.ListTrainer')
english_bot.set_trainer(ListTrainer)


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get")
def get_bot_response():
    userText = request.args.get('msg')
    response = str(english_bot.get_response(userText))
    #userText = request.args.get('msg')
    #response = generate_response(userText)

    appendfile=os.listdir('saved_conversations')[-1]
    appendfile= open('saved_conversations/'+str(filenumber),"a")
    appendfile.write('user : '+userText+'\n')
    appendfile.write('bot : '+response+'\n')
    appendfile.close()

    return response


if __name__ == "__main__":
    app.run(debug=True)
